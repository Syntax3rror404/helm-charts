# helm-charts/keycloak

[Keycloak](https://www.keycloak.org/) is an open source Identity and Access Management solution aimed at modern applications and services. It makes it easy to secure applications and services with little to no code.

## Introduction

This Helm chart deploys Keycloak on Kubernetes using the official Keycloak container image from quay.io/keycloak/keycloak.

It also provides a sidecar container for easyer managing custom keycloak themes.

### Database Options

The chart supports two database configuration methods:

1. **MariaDB Operator** (Recommended): Uses the official [mariadb-operator](https://github.com/mariadb-operator/mariadb-operator) to manage MariaDB instances
2. **External Database**: Connect to an existing database outside of this chart

**Important**: The MariaDB Operator must be pre-installed on your Kubernetes cluster if you choose option 1.

In short: 
```bash
helm repo add mariadb-operator https://helm.mariadb.com/mariadb-operator
helm install mariadb-operator-crds mariadb-operator/mariadb-operator-crds
helm install mariadb-operator mariadb-operator/mariadb-operator
```

### Key Features

- Official Keycloak image from Quay.io
- Custom theme support with sidecar container support to provide easyer theme installations
- Automatic admin credentials management via Kubernetes secrets
- Supports both new MariaDB instances and existing MariaDB deployments managed by the operator
- StatefulSet deployment for clustering and data consistency
- Infinispan clustering support with JGroups for multi-replica deployments
- Optional Ingress configuration with proxy header support
- Health probes for high availability
- Headless service for clustering communication

## Prerequisites

- Kubernetes 1.19+
- Helm 3.0+
- **MariaDB Operator** installed (if using `mariadbOperator.enabled: true`)
  - Installation guide: https://github.com/mariadb-operator/mariadb-operator

## Installation

### HTTPS

```bash
helm repo add syntax3rror404 https://syntax3rror404.github.io/helm-charts/charts
helm repo update
helm install keycloak syntax3rror404/keycloak -n keycloak --create-namespace -f myvalues.yaml
```

### OCI

```bash
helm install keycloak oci://ghcr.io/syntax3rror404/helm-charts/keycloak --version <version> -n keycloak --create-namespace -f myvalues.yaml
```

**Note**: A simple install uses default values like `admin/admin` for credentials. **You must create your own values file for production use.**

## Upgrade

```bash
helm upgrade keycloak syntax3rror404/keycloak -n keycloak
```

**Note**: The admin credentials are stored as secrets and will be preserved during upgrades.

## Uninstall

```bash
# Remove the Helm release
helm uninstall keycloak -n keycloak

# Delete the namespace (optional - this will remove all resources including PVCs)
kubectl delete ns keycloak
```

## Configuration

### Core Configuration Values

| Parameter | Default | Description |
|-----------|---------|-------------|
| `replicaCount` | `1` | Number of Keycloak replicas (use >1 for clustering) |
| `image.repository` | `quay.io/keycloak/keycloak` | Official Keycloak container image |
| `image.tag` | see values.yaml for value | Keycloak version |
| `image.pullPolicy` | `IfNotPresent` | Image pull policy |
| `admin.username` | `admin` | Keycloak admin username |
| `admin.password` | `admin` | Keycloak admin password (change in production!) |
| `updateStrategy` | `RollingUpdate` | StatefulSet update strategy |

### Keycloak Configuration

| Parameter | Default | Description |
|-----------|---------|-------------|
| `keycloak.proxy.headers` | `xforwarded` | Proxy headers mode (xforwarded, forwarded) |
| `keycloak.hostname.strict` | `false` | Enable strict hostname verification. Keep `false` to serve the same instance on multiple domains in parallel |
| `keycloak.cache.type` | `ispn` | Cache type (ispn for clustering, local for single node) |
| `keycloak.args` | `["start"]` | Keycloak args list |
| `keycloak.httpPath` | `"/"` | Keycloak used http path |

### Themes Configuration

This sidecar container allows you to manage keycloak themes e.g to use kubectl cp to copy a theme to the theme volume, because the keycloak container does not contain any binaries like tar etc.

After the theme installation you can disable the sidecar afterwards.

The volume is mounted to /themes.

After the installation of the theme you can enable the theme inside the realm settings.

| Parameter | Default | Description |
|-----------|---------|-------------|
| `themes.enabled` | `false` | Enable themes support |
| `themes.persistence.storageClass` | `` | Storage Class for storing themes |
| `themes.persistence.accessMode` | `ReadWriteMany` | Enable themes support |
| `themes.persistence.size` | `1Gi` | Size of themes volume |
| `themes.existingClaim` | `` | Use existing volume instead of creating new pvc |
| `themes.sidecar.enabled` | `false` | Start sidecar container inside keycloak pod for easyer theme management |
| `themes.sidecar.image` | `alpine:latest` | Image of sidecar container |
| `themes.sidecar.pullPolicy` | `IfNotPresent` | Image of sidecar container |
| `themes.sidecar.resources` | see values.yaml for defaults | Limit ressources for sidecar container |
| `themes.sidecar.securityContext` | `{}`  | Security context of sidecar container |

### Database Configuration - MariaDB Operator

| Parameter | Default | Description |
|-----------|---------|-------------|
| `mariadbOperator.enabled` | `false` | Enable MariaDB Operator integration |
| `mariadbOperator.database` | `keycloak` | Database name to create |
| `mariadbOperator.username` | `keycloak` | Database username to create |
| `mariadbOperator.password` | `keycloakpass` | Database password |
| `mariadbOperator.storageClass` | `longhorn` | Storage class for MariaDB |
| `mariadbOperator.useExisting.enabled` | `false` | Use existing MariaDB instance |
| `mariadbOperator.useExisting.namespace` | - | Namespace of existing MariaDB |
| `mariadbOperator.useExisting.mariaDbRef` | - | Name of existing MariaDB CR |

### Database Configuration - External Database

| Parameter | Default | Description |
|-----------|---------|-------------|
| `database.type` | `mariadb` | Database type (mariadb, postgres) |
| `database.name` | `keycloak` | Database name |
| `database.username` | `keycloak` | Database username |
| `database.password` | `keycloakpass` | Database password |
| `database.host` | `""` | Database host (auto-set with operator) |
| `database.port` | `3306` | Database port |
| `database.dbUrl` | `3306` | Database db url |

### Service Configuration

| Parameter | Default | Description |
|-----------|---------|-------------|
| `service.type` | `ClusterIP` | Service type |
| `service.port` | `8080` | Service port |

### Ingress Configuration

| Parameter | Default | Description |
|-----------|---------|-------------|
| `ingress.enabled` | `false` | Enable Ingress |
| `ingress.className` | `""` | Ingress class name (e.g., nginx) |
| `ingress.annotations` | `{}` | Ingress annotations |
| `ingress.hosts` | See values.yaml | Ingress hosts configuration |
| `ingress.tls` | `[]` | TLS configuration |

### Admin Ingress Configuration

Dedicated ingress for the admin console / admin REST endpoints (incl. the master realm). See [Separating the admin console / master realm](#separating-the-admin-console--master-realm).

| Parameter | Default | Description |
|-----------|---------|-------------|
| `adminIngress.enabled` | `false` | Enable the dedicated admin Ingress |
| `adminIngress.className` | `""` | Ingress class name (e.g. an internal-only class) |
| `adminIngress.annotations` | `{}` | Ingress annotations (e.g. IP allow-lists) |
| `adminIngress.hosts` | See values.yaml | Admin ingress hosts configuration |
| `adminIngress.tls` | `[]` | TLS configuration |

### Gateway API Configuration

| Parameter | Default | Description |
|-----------|---------|-------------|
| `httpRoute.enabled` | `false` | Enable GW API httpRoute |
| `httpRoute.annotations` | `{}` | http Route annotations |
| `httpRoute.hostnames` | `[keycloak.example.com]` | Public hostname(s) — multiple domains supported |
| `httpRoute.parentRefs` | See values.yaml | httproute parent ref |
| `httpRoute.matches` | `See values.yaml` | Match configuration |

### Admin Gateway API Configuration

Dedicated HTTPRoute for the admin console / admin REST endpoints (incl. the master realm). See [Separating the admin console / master realm](#separating-the-admin-console--master-realm).

| Parameter | Default | Description |
|-----------|---------|-------------|
| `adminHttpRoute.enabled` | `false` | Enable the dedicated admin HTTPRoute |
| `adminHttpRoute.annotations` | `{}` | http Route annotations |
| `adminHttpRoute.hostnames` | `{hostnames: [keycloak-admin.example.com]}` | Admin hostname |
| `adminHttpRoute.parentRefs` | See values.yaml | httproute parent ref (e.g. an internal Gateway) |
| `adminHttpRoute.matches` | See values.yaml | Match configuration |

## Separating the admin console / master realm

By default Keycloak serves the admin console (and therefore the `master` realm) on the same path space as the public authentication endpoints, so exposing your public host also exposes the admin surface. This chart separates them **at the path level** instead of pinning a fixed hostname — which means no `KC_HOSTNAME` is baked in and the same instance can be served on **multiple public domains in parallel**.

How it works:

- The **public** `ingress` / `httpRoute` only routes an allow-list of paths. The defaults are the exact set [Keycloak recommends exposing behind a reverse proxy](https://www.keycloak.org/server/reverseproxy#_exposed_path_recommendations): `/realms`, `/resources` and `/.well-known`. That is everything a login/OIDC flow needs (auth endpoints + the login UI's assets + authorization-server metadata). Keycloak explicitly recommends **not** exposing `/` (welcome page) and `/admin` (admin console + admin REST, incl. the master realm) — neither is in the list, so both return `404` on the public host(s).
- The dedicated **`adminIngress`** / **`adminHttpRoute`** route `/` (the whole instance, including `/admin`) on a separate, internal-only host that you can lock down with an internal ingress class / Gateway, an IP allow-list, or a separate TLS certificate.

To expose the admin console on the public host as well, simply add `/admin` to `ingress.hosts[].paths` / `httpRoute.matches`.

> **Note:** `/metrics` and `/health` are not in the allow-list either, but this chart already serves them on the separate management port `9000` (not on the `8080` service that the ingress points at), so they are never reachable through the public ingress regardless.

### Example: public + separate admin ingress (nginx, internal-only)

```yaml
# Public ingress: multiple domains, admin surface excluded via paths
ingress:
  enabled: true
  className: nginx
  annotations:
    cert-manager.io/cluster-issuer: letsencrypt-prod
  hosts:
    - host: auth.mycompany.com
      paths: &publicPaths
        - path: /realms
          pathType: Prefix
        - path: /resources
          pathType: Prefix
        - path: /.well-known
          pathType: Prefix
    - host: login.othertenant.com   # parallel domain, same instance
      paths: *publicPaths
  tls:
    - secretName: keycloak-tls
      hosts:
        - auth.mycompany.com
        - login.othertenant.com

# Admin ingress: internal host, serves the whole instance incl. /admin
adminIngress:
  enabled: true
  className: nginx
  annotations:
    cert-manager.io/cluster-issuer: letsencrypt-prod
    nginx.ingress.kubernetes.io/whitelist-source-range: "10.0.0.0/8"
  hosts:
    - host: keycloak-admin.internal.mycompany.com
      paths:
        - path: /
          pathType: Prefix
  tls:
    - secretName: keycloak-admin-tls
      hosts:
        - keycloak-admin.internal.mycompany.com
```

### Example: public + separate admin HTTPRoute (Gateway API)

```yaml
httpRoute:
  enabled: true
  hostnames:
    - auth.mycompany.com
    - login.othertenant.com   # parallel domain, same instance
  parentRefs:
    - group: gateway.networking.k8s.io
      kind: Gateway
      name: envoy-gateway-external
      namespace: envoy-gateway-system
  matches:
    - path: { type: PathPrefix, value: /realms }
    - path: { type: PathPrefix, value: /resources }
    - path: { type: PathPrefix, value: /.well-known }

adminHttpRoute:
  enabled: true
  hostnames:
    - keycloak-admin.internal.mycompany.com
  parentRefs:
    - group: gateway.networking.k8s.io
      kind: Gateway
      name: envoy-gateway-internal
      namespace: envoy-gateway-system
  matches:
    - path: { type: PathPrefix, value: / }
```

> **Note on `/realms/master`:** The path allow-list blocks the admin console (`/admin`). The master realm's own OIDC endpoints live under `/realms/master`, which is a sub-path of the allow-listed `/realms` — plain Ingress/Gateway prefix matching can't exclude a single sub-path, so those endpoints stay reachable on the public host. This is low risk once `/admin` is blocked (no admin console to drive them, and Keycloak's brute-force protection still applies). If you need to block them too, use a controller-specific deny rule, e.g. for nginx:
>
> ```yaml
> ingress:
>   annotations:
>     nginx.ingress.kubernetes.io/server-snippet: |
>       location ~* "^/realms/master" { return 404; }
> ```

### Health Probes

| Parameter | Default | Description |
|-----------|---------|-------------|
| `livenessProbe.httpGet.path` | `/health/live` | Liveness probe path |
| `livenessProbe.httpGet.port` | `9000` | Liveness probe port |
| `livenessProbe.periodSeconds` | `10` | Probe check interval |
| `readinessProbe.httpGet.path` | `/health/ready` | Readiness probe path |
| `readinessProbe.httpGet.port` | `9000` | Readiness probe port |
| `readinessProbe.periodSeconds` | `10` | Probe check interval |

## Configuration Examples

### Example 1: Single Instance with New MariaDB

```yaml
# myvalues.yaml
mariadbOperator:
  enabled: true
  database: keycloak
  username: keycloak
  password: "SecurePassword123!"
  storageClass: longhorn

admin:
  username: admin
  password: "ChangeMe123!"

keycloak:
  proxy:
    headers: xforwarded
  cache:
    type: local  # Single instance doesn't need clustering
  hostname:
    strict: false

ingress:
  enabled: true
  className: nginx
  annotations:
    cert-manager.io/cluster-issuer: letsencrypt-prod
  hosts:
    - host: auth.mycompany.com
      paths:
        - path: /
          pathType: Prefix
  tls: 
    - secretName: keycloak-tls
      hosts:
        - auth.mycompany.com

podSecurityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  fsGroup: 1000
  seccompProfile:
    type: RuntimeDefault

securityContext:
  allowPrivilegeEscalation: false
  capabilities:
    drop:
      - ALL
```

### Example 2: Clustered Setup with Existing MariaDB

```yaml
# myvalues.yaml
replicaCount: 3  # For high availability

mariadbOperator:
  enabled: true
  database: keycloak
  username: keycloak
  password: "SecurePassword123!"
  useExisting:
    enabled: true
    namespace: database
    mariaDbRef: mariadb-shared

admin:
  username: admin
  password: "SuperSecure456!"

keycloak:
  proxy:
    headers: xforwarded
  cache:
    type: ispn  # Infinispan for clustering
  hostname:
    strict: true

ingress:
  enabled: true
  className: nginx
  annotations:
    cert-manager.io/cluster-issuer: letsencrypt-prod
    nginx.ingress.kubernetes.io/affinity: "cookie"
    nginx.ingress.kubernetes.io/session-cookie-name: "route"
  hosts:
    - host: sso.mycompany.com
      paths:
        - path: /
          pathType: Prefix
  tls: 
    - secretName: keycloak-tls
      hosts:
        - sso.mycompany.com

resources:
  limits:
    cpu: 2000m
    memory: 2Gi
  requests:
    cpu: 500m
    memory: 1Gi

podSecurityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  fsGroup: 1000
  seccompProfile:
    type: RuntimeDefault

securityContext:
  allowPrivilegeEscalation: false
  capabilities:
    drop:
      - ALL
```

### Example 3: External PostgreSQL Database

```yaml
# myvalues.yaml
mariadbOperator:
  enabled: false

database:
  type: postgres
  name: keycloak_prod
  username: keycloak_user
  password: "ExternalDbPassword!"
  host: postgres.database.svc.cluster.local
  port: 5432

admin:
  username: admin
  password: "AdminPassword123!"

keycloak:
  proxy:
    headers: xforwarded
  cache:
    type: ispn

ingress:
  enabled: true
  className: nginx
  hosts:
    - host: keycloak.example.com
      paths:
        - path: /
          pathType: Prefix

podSecurityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  fsGroup: 1000
  seccompProfile:
    type: RuntimeDefault

securityContext:
  allowPrivilegeEscalation: false
  capabilities:
    drop:
      - ALL

```

### Example 4: Development Setup

```yaml
# dev-values.yaml
replicaCount: 1

mariadbOperator:
  enabled: true
  database: keycloak_dev
  username: keycloak
  password: "devpass"
  storageClass: local-path

admin:
  username: admin
  password: admin

keycloak:
  proxy:
    headers: xforwarded
  cache:
    type: local
  hostname:
    strict: false

ingress:
  enabled: true
  className: nginx
  hosts:
    - host: keycloak.local
      paths:
        - path: /
          pathType: Prefix

resources:
  limits:
    memory: 512Mi
  requests:
    cpu: 100m
    memory: 256Mi
```

## Architecture

### StatefulSet Deployment

The chart uses a StatefulSet to ensure:
- Stable network identity for each pod
- Ordered deployment and scaling
- Consistent pod naming for clustering

### Clustering with Infinispan

When `replicaCount > 1` and `keycloak.cache.type: ispn`:
- JGroups is used for cluster communication
- Headless service enables pod-to-pod communication
- Ports 7800 (jgroups) and 57800 (jgroups-fd) are exposed
- Each pod discovers others using Kubernetes DNS

### Services

Two services are created:
1. **Regular Service**: External access to Keycloak
2. **Headless Service**: Internal cluster communication

### Admin Credentials Management

Admin credentials are stored as Kubernetes secrets:
- Secret name: `<release-name>-admin`
- Contains: `username` and `password` keys
- Preserved during upgrades
- Can be rotated by deleting the secret and upgrading

### Database Connection

**With MariaDB Operator**:
- Automatic service discovery: `mariadb-<release-name>-internal.<namespace>.svc:3306`
- Database, User, and Grant resources are created automatically

**With External Database**:
- Configure connection via `database.*` values
- Connection string built from provided values

## Troubleshooting

### Database Connection Issues

Check the database connectivity:

```bash
# Check pod logs
kubectl logs -n keycloak -l app.kubernetes.io/name=keycloak

# Verify MariaDB Operator resources
kubectl get mariadb,database,user,grant -n keycloak

# Test database connection from pod
kubectl exec -n keycloak keycloak-0 -- sh -c "nc -zv <db-host> 3306"
```

### Clustering Issues

Verify cluster formation:

```bash
# Check if all pods are ready
kubectl get pods -n keycloak

# Check JGroups logs
kubectl logs -n keycloak keycloak-0 | grep -i jgroups

# Verify headless service
kubectl get svc -n keycloak
kubectl get endpoints -n keycloak
```

### Admin Password Reset

To reset the admin password:

```bash
# Delete the admin secret
kubectl delete secret keycloak-admin -n keycloak

# Update your values file with new password and upgrade
helm upgrade keycloak syntax3rror404/keycloak -n keycloak -f myvalues.yaml
```

### Proxy/Ingress Issues

If Keycloak shows incorrect URLs:

1. Verify `keycloak.proxy.headers` matches your ingress configuration
2. Check ingress annotations are correct
3. Ensure TLS is properly configured if using HTTPS

```bash
# Check ingress configuration
kubectl describe ingress -n keycloak

# Test from inside cluster
kubectl run -n keycloak test --rm -it --image=curlimages/curl -- sh
curl -v http://keycloak:8080
```

### Health Check Failures

If pods are not becoming ready:

```bash
# Check health endpoint manually
kubectl exec -n keycloak keycloak-0 -- curl http://localhost:9000/health/ready

# Check startup logs
kubectl logs -n keycloak keycloak-0 --tail=100

# Verify database migrations completed
kubectl logs -n keycloak keycloak-0 | grep -i migration
```

## Production Recommendations

### Security

1. **Change default passwords** in your values file
2. **Use Kubernetes secrets** for sensitive data
3. **Enable TLS** via Ingress with cert-manager
4. **Configure pod security contexts**:
   ```yaml
   podSecurityContext:
     fsGroup: 1000
     runAsNonRoot: true
   
   securityContext:
     allowPrivilegeEscalation: false
     runAsUser: 1000
     capabilities:
       drop:
         - ALL
   ```

### High Availability

1. **Run multiple replicas** (`replicaCount: 3`)
2. **Use Infinispan clustering** (`keycloak.cache.type: ispn`)
3. **Configure pod anti-affinity**:
   ```yaml
   affinity:
     podAntiAffinity:
       preferredDuringSchedulingIgnoredDuringExecution:
         - weight: 100
           podAffinityTerm:
             labelSelector:
               matchExpressions:
                 - key: app.kubernetes.io/name
                   operator: In
                   values:
                     - keycloak
             topologyKey: kubernetes.io/hostname
   ```

### Performance

1. **Set appropriate resource limits**:
   ```yaml
   resources:
     limits:
       cpu: 2000m
       memory: 2Gi
     requests:
       cpu: 500m
       memory: 1Gi
   ```

2. **Configure database connection pooling** (if using external DB)

3. **Use persistent storage** for themes and extensions (add volumeMounts)

### Monitoring

1. Enable metrics endpoint (requires additional configuration)
2. Use Prometheus ServiceMonitor (if using Prometheus Operator)
3. Monitor health endpoints via your monitoring solution

## Migration from Other Deployments

### From Docker Compose

1. Export your database
2. Install MariaDB Operator on Kubernetes
3. Deploy this chart with `mariadbOperator.enabled: true`
4. Import your database to the new MariaDB instance
5. Update your DNS/URLs to point to the new Ingress

### From Bitnami Keycloak Chart

1. Backup your existing database
2. Note your current configuration and secrets
3. Install MariaDB Operator
4. Deploy this chart with equivalent configuration
5. Restore database if needed

## Advanced Configuration

### Custom Themes

To add custom themes, create a PVC and mount it:

```yaml
volumeMounts:
  - name: keycloak-themes
    mountPath: /opt/keycloak/themes/custom

volumes:
  - name: keycloak-themes
    persistentVolumeClaim:
      claimName: keycloak-themes-pvc
```

### Custom Providers

Similar to themes, mount your provider JARs:

```yaml
volumeMounts:
  - name: keycloak-providers
    mountPath: /opt/keycloak/providers

volumes:
  - name: keycloak-providers
    persistentVolumeClaim:
      claimName: keycloak-providers-pvc
```

### Environment Variables

Add custom environment variables via values:

```yaml
# Note: This requires extending the StatefulSet template
env:
  - name: KC_LOG_LEVEL
    value: INFO
  - name: KC_FEATURES
    value: "preview"
```

## Support and Contributing

- **Issues**: https://github.com/Syntax3rror404/helm-charts/issues
- **Source Code**: https://github.com/Syntax3rror404/helm-charts
- **Keycloak Documentation**: https://www.keycloak.org/documentation
- **MariaDB Operator**: https://github.com/mariadb-operator/mariadb-operator
